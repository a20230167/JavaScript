document.write("<h1>Bievenidos a la pagina de JavaScript<h1>");
var non = prompt("Ingrese su nombre");
document.write(
  "Hola " + non + " es tu primer contacto con la programación en JavaScript"
);
